bs -os RHEL6 ./run_actc_gen.sh
