#!/bin/csh -f

#set ACTC_PATH = "/common/appl/Renesas/MCU_PF/STA/perl/bin"
set ACTC_PATH = "/design02/RX100_NEXT/user/chenxi/Ciesta/AC/v101/bin"
set IN_EXCEL_VCC2p7 = ./EXCEL/RX140_64K_AC_Timing_Ciesta_20200709_VCC2p7.xls
set IN_EXCEL_VCC2p4 = ./EXCEL/RX140_64K_AC_Timing_Ciesta_20200709_VCC2p4.xls
set IN_EXCEL_VCC1p8 = ./EXCEL/RX140_64K_AC_Timing_Ciesta_20200709_VCC1p8.xls

if !(-d LOG) mkdir LOG
set date = `date '+%y%m%d_%H%M'`

################################################################################
echo ""
echo ""
echo "##### CLKGEN #####"

################################################################################

### VCC 2P7 ####################################################################
set dir=tcl_actc_VCC2p7
rm -rf $dir
bs -os RHEL5 perl $ACTC_PATH/sta-clk_gen.pl \
  $IN_EXCEL_VCC2p7 "Chip_Clocks" \
  -out_dir $dir \
 | & tee -i ./LOG/log_clk_gen_VCC2p7.log


bs -os RHEL5 perl $ACTC_PATH/actc_gen.pl.v00.0045 \
  $IN_EXCEL_VCC2p7 \
  Port_Func \
  -clk_sheet "Chip_Clocks" \
  -pcm $IN_EXCEL_VCC2p7 \
  -out_dir $dir \
 | & tee -i ./LOG/log_ac_timing_STA_VCC2p7.log

### VCC 2P4 ####################################################################
set dir=tcl_actc_VCC2p4
rm -rf $dir
bs -os RHEL5 perl $ACTC_PATH/sta-clk_gen.pl \
  $IN_EXCEL_VCC2p4 "Chip_Clocks" \
  -out_dir $dir \
 | & tee -i ./LOG/log_clk_gen_VCC2p4.log


bs -os RHEL5 perl $ACTC_PATH/actc_gen.pl.v00.0045 \
  $IN_EXCEL_VCC2p4 \
  Port_Func \
  -clk_sheet "Chip_Clocks" \
  -pcm $IN_EXCEL_VCC2p4 \
  -out_dir $dir \
 | & tee -i ./LOG/log_ac_timing_STA_VCC2p4.log

### VCC 1P8 ####################################################################
set dir=tcl_actc_VCC1p8
rm -rf $dir
bs -os RHEL5 perl $ACTC_PATH/sta-clk_gen.pl \
  $IN_EXCEL_VCC1p8 "Chip_Clocks" \
  -out_dir $dir \
 | & tee -i ./LOG/log_clk_gen_VCC1p8.log


bs -os RHEL5 perl $ACTC_PATH/actc_gen.pl.v00.0045 \
  $IN_EXCEL_VCC1p8 \
  Port_Func \
  -clk_sheet "Chip_Clocks" \
  -pcm $IN_EXCEL_VCC1p8 \
  -out_dir $dir \
 | & tee -i ./LOG/log_ac_timing_STA_VCC1p8.log


### SCI Slave latch ############################################################
sed -i -e 's/-rise_to/-to/g' -e 's/-fall_to/-to/g' tcl_actc_VCC*/report/ac_report_SCI*Slave.tcl

### DAXS DATAO dax_oe ##########################################################
sed -i -e 's/iotop\/mpc\/dax_oe //g' tcl_actc_VCC*/const/ac_const_DAXS.tcl

################################################################################
# Tempus-translate
################################################################################
rm -rf impl_astc_tps
setenv TRANS_SCR_PATH     ../../../STA_env/20200622_STA_env/Rev1.10/Reference/script/common_tps/utility
setenv TRANS_WRAPPER_PATH ${TRANS_SCR_PATH}
setenv TRANS_VARLIST_FILE ${TRANS_SCR_PATH}/var.list

${TRANS_SCR_PATH}/trans_scr_wrapper.batch tcl_actc_VCC2p7 tcl_actc_VCC2p7_tps
mv log.trans_scr_wrapper ./LOG/log.trans_scr_wrapper_2p7

${TRANS_SCR_PATH}/trans_scr_wrapper.batch tcl_actc_VCC2p4 tcl_actc_VCC2p4_tps
mv log.trans_scr_wrapper ./LOG/log.trans_scr_wrapper_2p4

${TRANS_SCR_PATH}/trans_scr_wrapper.batch tcl_actc_VCC1p8 tcl_actc_VCC1p8_tps
mv log.trans_scr_wrapper ./LOG/log.trans_scr_wrapper_1p8

sed -i *_tps/*.tcl -e 's/\(source .*r_tcl\.pt\)/# \1/g'
sed -i tcl_actc_VCC*_tps/read_clk.tcl -e 's/\(source .*clk_thr_chk.tcl\)/# \1/g'


