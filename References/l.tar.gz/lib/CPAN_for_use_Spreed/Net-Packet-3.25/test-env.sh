export NP_DO_TEST=1
export NP_DO_TEST6=1
export NP_DEBUG=0

export NP_LO_DEV=lo
export NP_LO_IP=localhost
export NP_LO_IP6=localhost
export NP_LO_TARGET_IP=localhost
export NP_LO_TARGET_IP6=localhost
export NP_LO_TARGET_PORT=443

export NP_ETH_DEV=eth0
export NP_ETH_IP=source
export NP_ETH_IP6=source
export NP_ETH_MAC=00:00:00:00:00:01
export NP_ETH_TARGET_IP=target
export NP_ETH_TARGET_IP6=target
export NP_ETH_TARGET_MAC=00:00:00:00:00:02
export NP_ETH_TARGET_PORT=443
