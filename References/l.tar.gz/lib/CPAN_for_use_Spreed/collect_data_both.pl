#!/usr/bin/perl  -I/shsv/SHX2/user/phongvo/Send/Perl/Bin

use Shell qw(ls rm mv);
#use Fink::Command ':ALL';
use English;
use Switch;
use Spreadsheet::WriteExcel;
use Spreadsheet::WriteExcel::Utility;
use Getopt::Long;

sub parse_file() {
	open(localfile,"eembc.list") || die "can't open eembc.list \n";
	local $counter = 0;
	local $line =<localfile> ;
	start:	
		$line =~ /[a-zA-Z]+/;
		$match = $&;
		switch ( $match ) {
		case "automotive" {
			$counter = 0;
			while ($line = <localfile>) {
			
			if ( $line =~ /\[[a-zA-Z]+\]/ ) {
				goto start;
				
			}
			else {
				$line = lc($line);
				$automotive[$counter]=$line;
				$counter++;
			}
			}
		}

		case "consumer" {
			$counter = 0;
			while ($line = <localfile>) {
			if ( $line =~ /\[[a-zA-Z]+\]/ ) {
				goto start;
				
			}
			else {
				$line = lc($line);
				$consumer[$counter]=$line;
				$counter++;
			}
			}
		}

		case "office" {
			$counter = 0;
			while ($line = <localfile>) {
			
			if ( $line =~ /\[[a-zA-Z]+\]/ ) {
				goto start;
				
			}
			else {
				$line = lc($line);
				$office[$counter]=$line;
				$counter++;
			}
			}
		}

		case "telecom" {
			$counter = 0;
			while ($line = <localfile>) {
			if ( $line =~ /\[[a-zA-Z]+\]/ ) {
				goto start;
				
			}
			else {
				$line = lc($line);
				$telecom[$counter]=$line;
				$counter++;
			}
			}
		}
		
		case "networking" {
			$counter = 0;
			while ($line = <localfile>) {
			if ( $line =~ /\[[a-zA-Z]+\]/ ) {
				goto start;
				
			}
			else {
				$line = lc($line);
				$networking[$counter]=$line;
				$counter++;
			}
			}
		}

		}
	close(localfile); 
}

sub write_file() {
my ($filename,@list_file) = @_;

my $work_sheet = $work_book->add_worksheet($filename);

$work_sheet->set_column(0,20,10);
$work_sheet->set_column(0,0,18);
$column = 1;


foreach $benchmark (@list_file) {
	$row = 0;	
	chomp($filename);
	$benchmark =~ s/^[\s]*//;
	$benchmark =~ s/[\s]*$//;
	if ( $benchmark eq "" ) { print "I have null file \n";	}
	else {
	$filename = $benchmark."_lite.txt";
	$work_sheet->write_string($row,$column1,$benchmark);
	open(read_ptr,$filename) || die "Can't open $filename to read \n";
	#open(read_ptr,$filename);
# 	if ( read_ptr eq "" ) {
# 	next ; 
# 	}
# 	
	$counter = 0;
	$total_time = 0; 
	$index = 0;
	$min = 123456789;

read_again:
	while ( $line = <read_ptr>) {
		if ( $line =~ /Summary[\s]+utime/i  ) {
			
			($tmp1,$tmp2,$tmp3) = split (':',$line);
			
			$tmp2 =~ s/^[\s]*//;
			$tmp2 =~ s/][\s]*$//;

			($tmp4,$iteration) = split(/\s/,$tmp2);
	
			$tmp3 =~ s/^[\s]*//;
			$tmp3 =~ s/[\s]*$//;

			($tmp5,$sec,$tmp6,$usec) = split(/\s/,$tmp3);
			
			while ( $line = <read_ptr>) {
			if ( $line =~ /Summary utime/i  ) {
			($tmp11,$tmp21,$tmp31) = split(':',$line);

			$tmp21 =~ s/^[\s]*//;
			$tmp21 =~ s/][\s]*$//;
			($tmp41,$iteration1) = split(/\s/,$tmp21);

			
			$tmp31 =~ s/^[\s]*//;
			$tmp31 =~ s/[\s]*$//;
			($tmp51,$sec1,$tmp61,$usec1) = split(/\s/,$tmp31);
			

			$iteration = abs($iteration-$iteration1);
			$data[$counter] = abs($sec-$sec1)*1000 + abs($usec-$usec1)/1000;
			if ( $min > $data[$counter] ) {$min = $data[$counter];}
			
			#print "iter $iteration data $data[$counter] \n"; 
			$counter++;
			goto read_again;
				}
			}	
		}
	}
		
	#print " min is $min \n";
	$row = 1;
	$data_abnormal=0;
	$index=0;
	for ( $i=0;$i<$counter;$i++) {
		$result =abs($data[$i] - $min);
 		if ( $result >= $limit ) {
		
		#print "min is $min\n";
 		$work_sheet->write_number($row++,$column,$data[$i],$format_problem);
		
 		}
		else {
		$work_sheet->write_number($row++,$column,$data[$i],$format);
		$data_abnormal+=$data[$i];
		$index++;
		}
		
 	}
	if ( $index > 0 ) {
	$data_abnormal/=$index;
	}
	#$format->set_bg_color('white');

	$row+=2;
	$end=$row;
	
	$str_start=xl_rowcol_to_cell(1, $column);  #for example B2
	$str_end=xl_rowcol_to_cell($counter,$column);

	# counter
	$work_sheet->write_number($row,$column,$counter);
	
	#$work_sheet->write_string($row,0,"Iterations");
	$work_sheet->write_number(++$row,$column,$iteration);
	$str_iter = xl_rowcol_to_cell($row,$column);
	#$work_sheet->write_string($row,0,"Total Times");
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet->write_formula(++$row,$column,"=SUM($str_start:$str_end)");
	$str_sum=xl_rowcol_to_cell($row,$column);
	$row++;
	#$work_sheet->write_string($row,0,"Time Avg");
 	#$total_time = $total_time / $counter;
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet->write_formula(++$row,$column,"=AVERAGE($str_start:$str_end)");
	$str_avg=xl_rowcol_to_cell($row,$column);

	#$total_time = $total_time/$iteration;
 	#$total_time = 1/$total_time;
	#$work_sheet->write_string(++$end,0,"Iter/Time");
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet->write_formula(++$row,$column,"=($str_iter/$str_avg)");
	$str_iter_time = xl_rowcol_to_cell($row,$column);
 	#$total_time = $total_time * (5/3);
	#print " total time $total_time \n";
	#$work_sheet->write_string(++$end,0,"Iter/Million Cycles");
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet->write_formula(++$row,$column,"=($str_iter_time*5/3)");

	#$row++;
	$formula = "=VAR($str_start:$str_end)";
	$work_sheet->write_formula(++$row,$column,$formula);
	$row++;
#####################################################
	$work_sheet->write_number(++$row,$column,$data_abnormal);
	$str_avg_wo_abnormal=xl_rowcol_to_cell($row,$column);

	$work_sheet->write_formula(++$row,$column,"=($str_iter/$str_avg_wo_abnormal)");
	$str_iter_time_wo_abnormal=xl_rowcol_to_cell($row,$column);
	$work_sheet->write_formula(++$row,$column,"=($str_iter_time_wo_abnormal*5/3)");
	close(read_ptr);
	
 	$column++;
	}
}
	$work_sheet->set_row($end-1,10,$format_blank);
	$work_sheet->write_string($end,0,"Counters");
	$work_sheet->write_string(++$end,0,"Iterations");
	$work_sheet->write_string(++$end,0,"Total Time");
	$end++;
	$work_sheet->set_row($end,10,$format_blank);

	$work_sheet->write_string(++$end,0,"Normal Time Avg");
	$work_sheet->write_string(++$end,0,"Normal Iter/Time Avg");
	$work_sheet->write_string(++$end,0,"Normal Iter/Million Cycles Avg");
	#$end++;
	$work_sheet->write_string(++$end,0,"Variance");
	
	$work_sheet->set_row(++$end,10,$format_blank);
	
	$work_sheet->write_string(++$end,0,"Time Avg Without Abnormal Data");
	$work_sheet->write_string(++$end,0,"Iter/Time Avg Without Abnormal Data");
	$work_sheet->write_string(++$end,0,"Normal Iter/Million Cycles Avg Without Abnormal  ");
	########
	$end +=5;
	$work_sheet->write_string($end,0,"Presumed that frequency of RP1 board is 600 MHz ; LinuxRP1 with UP configuration");
	$work_sheet->write_string(++$end,0,"GCC Version 3.4.5 GLibc don't know");
	$work_sheet->write_string(++$end,0,"GCC option : -O3 -funroll-loops   --param max-inline -insns -single=50000	");
	$end+=2;
	$work_sheet->write_string(++$end,0,"If data is greater than min $limit units, it will be filled with yellow color"); 
}

sub write_file2() {
	my ($filename,@list_file) = @_;

	my $work_sheet2 = $work_book2->add_worksheet($filename);

$work_sheet2->set_column(0,20,10);
$work_sheet2->set_column(0,0,18);
$column = 1;


foreach $benchmark (@list_file) {
	$row = 0;	
	chomp($filename);
	$benchmark =~ s/^[\s]*//;
	$benchmark =~ s/[\s]*$//;
	if ( $benchmark eq "" ) { print "I have null file \n";	}
	else {
	$filename = $benchmark."_lite.txt";
	$work_sheet2->write_string($row,$column,$benchmark);
	#open(read_ptr,$filename) || die "Can't open $filename to read \n";
	open(read_ptr,$filename);
	if ( read_ptr eq "" ) {
	next ;
	}
	
	$counter = 0;
	$total_time = 0; 
	$index = 0;
	$min = 123456789;

read_again:
	while ( $line = <read_ptr>) {
		
		if ( $line =~ /Iterations[\s]+\=/i  ) {
			$line =~ /[0-9]+/;
			$iteration = $&;
			
		}
		elsif ( $line =~  /Target[\s]+Duration[\s]+\=/i ) {
			$line =~ /[0-9]+/ ;
			$duration = $&;
		while ( $line = <read_ptr>) {
			if ( $line =~ /Iterations[\s]+\=/i  ) {
			$line =~ /[0-9]+/;
			$iteration2 = $&;
			}
		elsif ( $line =~  /Target[\s]+Duration[\s]+\=/i ) {
			$line =~ /[0-9]+/ ;
			$duration2 = $&;
			$iteration = abs($iteration-$iteration2);
			$data[$counter] = abs($duration - $duration2);
			if ( $min > $data[$counter] ) {$min = $data[$counter];}
			$counter++;
			goto read_again;
			}
		}
		}
		
	}	
	
	#print " min is $min \n";
	$row = 1;
	$data_abnormal=0;
	$index=0;
	for ( $i=0;$i<$counter;$i++) {
		$result =abs($data[$i] - $min);
 		if ( $result >= $limit ) {
		
		#print "min is $min\n";
 		$work_sheet2->write_number($row++,$column,$data[$i],$format_problem2);
		
 		}
		else {
		$work_sheet2->write_number($row++,$column,$data[$i],$format2);
		$data_abnormal+=$data[$i];
		$index++;
		}
		
 	}
	if ( $index > 0 ) {
	$data_abnormal/=$index;
	}
	#$format->set_bg_color('white');

	$row+=2;
	$end=$row;
	
	$str_start=xl_rowcol_to_cell(1, $column);  #for example B2
	$str_end=xl_rowcol_to_cell($counter,$column);

	# counter
	$work_sheet2->write_number($row,$column,$counter);
	
	#$work_sheet->write_string($row,0,"Iterations");
	$work_sheet2->write_number(++$row,$column,$iteration);
	$str_iter = xl_rowcol_to_cell($row,$column);
	#$work_sheet->write_string($row,0,"Total Times");
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet2->write_formula(++$row,$column,"=SUM($str_start:$str_end)");
	$str_sum=xl_rowcol_to_cell($row,$column);
	$row++;
	#$work_sheet->write_string($row,0,"Time Avg");
 	#$total_time = $total_time / $counter;
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet2->write_formula(++$row,$column,"=AVERAGE($str_start:$str_end)");
	$str_avg=xl_rowcol_to_cell($row,$column);

	#$total_time = $total_time/$iteration;
 	#$total_time = 1/$total_time;
	#$work_sheet->write_string(++$end,0,"Iter/Time");
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet2->write_formula(++$row,$column,"=($str_iter/$str_avg)");
	$str_iter_time = xl_rowcol_to_cell($row,$column);
 	#$total_time = $total_time * (5/3);
	#print " total time $total_time \n";
	#$work_sheet->write_string(++$end,0,"Iter/Million Cycles");
	#$work_sheet->write_number(++$row,$column,$total_time);
	$work_sheet2->write_formula(++$row,$column,"=($str_iter_time*5/3)");

	#$row++;
	$formula = "=VAR($str_start:$str_end)";
	$work_sheet2->write_formula(++$row,$column,$formula);
	$row++;
#####################################################
	$work_sheet2->write_number(++$row,$column,$data_abnormal);
	$str_avg_wo_abnormal=xl_rowcol_to_cell($row,$column);

	$work_sheet2->write_formula(++$row,$column,"=($str_iter/$str_avg_wo_abnormal)");
	$str_iter_time_wo_abnormal=xl_rowcol_to_cell($row,$column);
	$work_sheet2->write_formula(++$row,$column,"=($str_iter_time_wo_abnormal*5/3)");
	close(read_ptr);
	
 	$column++;
	}
}
	$work_sheet2->set_row($end-1,10,$format_blank);
	$work_sheet2->write_string($end,0,"Counters");
	$work_sheet2->write_string(++$end,0,"Iterations");
	$work_sheet2->write_string(++$end,0,"Total Time");
	$end++;
	$work_sheet2->set_row($end,10,$format_blank);

	$work_sheet2->write_string(++$end,0,"Normal Time Avg");
	$work_sheet2->write_string(++$end,0,"Normal Iter/Time Avg");
	$work_sheet2->write_string(++$end,0,"Normal Iter/Million Cycles Avg");
	#$end++;
	$work_sheet2->write_string(++$end,0,"Variance");
	
	$work_sheet2->set_row(++$end,10,$format_blank);
	
	$work_sheet2->write_string(++$end,0,"Time Avg Without Abnormal Data");
	$work_sheet2->write_string(++$end,0,"Iter/Time Avg Without Abnormal Data");
	$work_sheet2->write_string(++$end,0,"Normal Iter/Million Cycles Avg Without Abnormal  ");
	########
	$end +=5;
	$work_sheet2->write_string($end,0,"Presumed that frequency of RP1 board is 600 MHz ; LinuxRP1 with UP configuration");
	$work_sheet2->write_string(++$end,0,"GCC Version 3.4.5 GLibc don't know");
	$work_sheet2->write_string(++$end,0,"GCC option : -O3 -funroll-loops   --param max-inline -insns -single=50000	");
	$end+=2;
	$work_sheet2->write_string(++$end,0,"If data is greater than min $limit units, it will be filled with yellow color"); 

}
# sub unify_name() {
#   local @list = ls ("*.txt*");
#   print "list is @list \n";
# 	foreach $file (@list ) {
# 	chomp($file);
# 	($name,$extension) = split(/\./,$file);
# 	$name = $name.".txt";
# 	mv("$file tmp.text");
# 	mv("tmp.text $name");
# #	open(fileread,$file) || die "Can't open $file \n";
# #	close(fileread);
# 	}
# 	
# 	} 


$limit = 1;
$mode = 1;
GetOptions("l|L|Limit|limit=i"=>\$limit,"m|M=s"=>\$mode);


&parse_file();

if ( $mode == 2 ) {
$work_book  = Spreadsheet::WriteExcel->new("eembc_gcc_up.xls");
$format=$work_book->add_format();
$format->set_align('center');
$format->set_size('10');
$format->set_bg_color('white');

$format_problem=$work_book->add_format();
#$format_problem=$format;
$format_problem->set_align('center');
$format_problem->set_size('10');
$format_problem->set_bg_color('yellow');

$format_blank=$work_book->add_format();
#$format_problem=$format;
$format_blank->set_align('center');
$format_blank->set_size('10');
$format_blank->set_bg_color('green');

&write_file("automotive",@automotive);
&write_file("consumer",@consumer);
&write_file("networking",@networking);
&write_file("office",@office);
&write_file("telecom",@telecom);
$work_book->close();
}

$work_book2  = Spreadsheet::WriteExcel->new("eembc_gcc_up_duration.xls");

$format2=$work_book2->add_format();
$format2->set_align('center');
$format2->set_size('10');
$format2->set_bg_color('white');

$format_problem2=$work_book2->add_format();
#$format_problem=$format;
$format_problem2->set_align('center');
$format_problem2->set_size('10');
$format_problem2->set_bg_color('yellow');

$format_blank2=$work_book2->add_format();
#$format_problem=$format;
$format_blank2->set_align('center');
$format_blank2->set_size('10');
$format_blank2->set_bg_color('green');

&write_file2("automotive",@automotive);
&write_file2("consumer",@consumer);
&write_file2("networking",@networking);
&write_file2("office",@office);
&write_file2("telecom",@telecom);


$work_book2->close();
#&unify_name();