#! /usr/bin/tcsh

setenv OPT_RPT "-significant_digits 3 -capacitance -transition_time -nets -input_pins -nosplit -path_type full_clock_expanded -derate -voltage"

rm -rf impl_astc

mkdir log

#perl /common/appl/Renesas/MCU_PF/STA/perl/bin/astc_gen.pl \

perl ./bin/astc_gen.pl \
  -cond CONDITION -rpt_opt "${OPT_RPT}" \
  -outdir impl_astc \
  -file ./doc_astc/RX140_Kobetu_20200805_Spec.xls | tee log/astc.log

#exit

## Tempus-translate
#rm -rf impl_astc_tps
#setenv TRANS_SCR_PATH     /design02/A2E1/data/R7FA2E1A93/4_implement/46_sta/sta_env/Rev1.10/Reference/script/common_tps/utility
#setenv TRANS_WRAPPER_PATH ${TRANS_SCR_PATH}
#setenv TRANS_VARLIST_FILE ${TRANS_SCR_PATH}/var.list
#${TRANS_SCR_PATH}/trans_scr_wrapper.batch impl_astc impl_astc_tps
#
#sed -i impl_astc_tps/astc_config.tcl -e 's/\(source .*r_tcl\.pt\)/# \1/g'
#sed -i impl_astc_tps/const/*.tcl -e 's/save_design/save_design -overwrite/g'
#sed -i impl_astc_tps/const/*.tcl -e 's/\(read_design .*\)/\1.dat r7fa2e1/g'
#sed -i impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_CMP_1_atc_const.tcl -e 's/"\[/" [/g'
# WA.No6
#echo "create_clock -name iclk_thr -period 100  cspf/sysss/syspf/cpg/cgmaindft/cgmain/cgcksel/pclk2_mdrv/cg_en1/cg_nand2/A" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_BPM2_atc_const.tcl
#echo "reset_clock iclk_thr" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_BPM2_atc_const_reset.tcl
#echo "create_clock -name DUMMY_CLK -period 100 {pericore/mp200/iic_?/riic/iicip/iicctl/icsyn/sclin_d1_tck_reg/CLK pericore/mp200/iic_?/riic/iicip/iicctl/icsyn/sdain_d1_reg/CLK}" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RIIC_1_atc_const.tcl
#echo "reset_clock DUMMY_CLK" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RIIC_1_atc_const_reset.tcl
#echo "create_clock -name DUMMY_CLK -period 100 pericore/mp200/rspi_?/sgn/ssl0i1_r_reg/CLK" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_1_atc_const.tcl
#echo "reset_clock DUMMY_CLK" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_1_atc_const_reset.tcl
#echo "create_clock -name DUMMY_CLK -period 100 {pericore/mp200/rspi_?/sgn/ssl0i1_r_reg/CLK pericore/mp200/rspi_?/dtr/dck/recv_async1/din_async_r_reg/CLK}" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_2_atc_const.tcl
#echo "reset_clock DUMMY_CLK" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_2_atc_const_reset.tcl
#echo "create_clock -name DUMMY_CLK -period 100 {pericore/mp200/rspi_?/dtr/dck/recv_async1/din_async_r_reg/CLK pericore/mp200/rspi_?/dtr/dio/mosii1_r_reg/CLK}" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_3_atc_const.tcl
#echo "reset_clock DUMMY_CLK" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_3_atc_const_reset.tcl
#echo "create_clock -name DUMMY_CLK -period 100 {pericore/mp200/rspi_?/dtr/dio/slave_txbit/dout_r_reg/CLK}" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_6_atc_const.tcl
#echo "reset_clock DUMMY_CLK" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_RSPI_6_atc_const_reset.tcl
#
## WA.No7
#echo "set_false_path -through iotop/pad/P*/P1*/ENI"                           >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_IDET1_atc_const.tcl
#echo "set_false_path -through cspf/sysss/syspf/clkmc/mosc_wrapper/osc/X?ENI"  >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_IDET1_atc_const.tcl
#echo "reset_path_exception -through iotop/pad/P*/P1*/ENI"                     >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_IDET1_atc_const_reset.tcl
#echo "reset_path_exception -through cspf/sysss/syspf/clkmc/mosc_wrapper/osc/X?ENI" >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_IDET1_atc_const_reset.tcl
#
#
#echo 'read_design ses_${MODE}_${CONDITION}_${SETUP_HOLD}.dat r7fa2e1' >> impl_astc_tps/const/PEAKS_YARI1_Kobetu_*_FLASH_3_atc_const_reset.tcl
#

sed -i 's/\] = ""/\] != "" \&\&/g' impl_astc/const/*MTU2* 
sed -i 's/direction=/direction!=/g' impl_astc/const/*MTU2* 
sed -i 's/\] = ""/\] != "" \&\&/g' impl_astc/const/*POE* 
sed -i 's/in  full_name/in \&\& full_name/g' impl_astc/const/*POE* 
sed -i 's/name =/name !=/g' impl_astc/const/*POE* 
sed -i 's/direction=/direction!=/g' impl_astc/const/*POE* 
sed -i 's/{ $path_a_thr }/$path_a_thr/g' impl_astc/*/*SYLPW2* 
#sed -i 's/#set\ CONDITION/set\ CONDITION/g' impl_astc/a*
