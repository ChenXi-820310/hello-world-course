bs -os RHEL6 ./run_astc.sh
